# src/fish_model.py
import numpy as np

def generate_fibonacci(n=15):
    """Task 1: Generates n Fibonacci numbers as a baseline stock model."""
    fib = [1, 1]
    for i in range(2, n):
        fib.append(fib[-1] + fib[-2])
    return fib

class FishStock():
    """Task 2: Discrete logistic growth model with proportional harvesting."""
    def __init__(self, r=0, K=10000.0, N0=4000.0):
        self.r = r  #Intrisic growth rate
        self.K = K  #Carrying capacity (tonnes)
        self.N0 = N0 #Initial stock (tonnes)

    def simulate(self, weeks=52, harvest_rate=0.1):
        """Simulates fish stock and harvests over a given number of weeks."""
        stock = np.zeros(weeks + 1)
        harvests = np.zeros(weeks)
        stock[0] = self.N0
        
        for t in range(weeks):
            # Harvest in tonnes for the current week based on current stock
            h_tonnes = harvest_rate * stock[t]
            harvests[t] = h_tonnes
            
            # Discrete logistic growth equation
            growth = self.r * stock[t] * (1.0 - stock[t] / self.K)
            next_stock = stock[t] + growth - h_tonnes
            
            # Stock cannot drop below zero
            stock[t+1] = max(0.0, next_stock)
            
        return stock, harvests



if __name__ == "__main__":
    print("--- Task 1: Fibonacci Stock Baseline ---")
    fib_stock = generate_fibonacci(15)
    print(f"Fibonacci Stock (15 weeks): {fib_stock}")
    print("\nBiological Critique:")
    print("Unbounded Fibonacci growth is biologically unrealistic because fish populations")
    print("in Lake Victoria face environmental carrying capacity limits (K), resource")
    print("competition, predation, and density-dependent mortality. Real ecosystems never")
    print("exhibit permanent exponential acceleration without bounds.")
    print("\n--- Task 2: FishStock Simulation (52 Weeks, h=0.1)---")
    model =FishStock(r=0.4, K=10000.0, N0=4000.0)
    stock_traj, harvest_traj = model.simulate(weeks=52, harvest_rate=0.1)
    print(f"Initial Stock: {stock_traj[0]:.2f} tonnes")
    print(f"Week 1 Stock: {stock_traj[1]:.2f} tonnes, Harvest: {harvest_traj[0]:.2f} tonnes")
    print(f"Final Stock (Week 52): {stock_traj[-1]:.2f} tonnes")
    