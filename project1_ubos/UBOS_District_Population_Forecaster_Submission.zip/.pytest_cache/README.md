# pytest cache directory #

This directory contains data from the pytest's cache plugin,
which provides the `--lf` and `--ff` options, as well as the `cache` fixture.

**Do not** commit this to version control.

See [the docs](https://docs.pytest.org/en/stable/how-to/cache.html) for more information.
# UBOS District Population Forecaster & Resource Planner

An object-oriented Python application designed to analyze, validate, forecast, and visualize population trends for 5 major Ugandan districts (Kampala, Wakiso, Gulu, Jinja, and Mbarara) using 10 years of historical data (2015–2024) provided by the Uganda Bureau of Statistics (UBOS).

---

## 📂 Project Structure

```text
my_project_root/
│
├── venv/                      # Python virtual environment
├── district_population_forecasts.png  # Saved visualization chart
├── README.md                  # Project documentation
│
└── src/                       # Source package folder
    ├── data_loader.py         # District data loader & dictionary initialization
    ├── district.py            # DistrictPopulation class (Stats, YoY, CAGR)
    ├── forecasters.py         # Abstract Forecaster base class & model subclasses
    ├── task2_stats.py         # Statistical benchmarks (NumPy vs statistics module)
    ├── task3_growth.py        # Year-on-Year growth rates and CAGR analysis
    ├── task5_validate.py      # Train/Test model validation (MAE, RMSE, MAPE)
    ├── task6_project.py       # Long-term exponential population projections to 2030
    ├── task7_visualize.py     # Matplotlib multi-panel visualization generator
    └── task8_planning.py      # Educational resource planning (Classroom requirements)
    └── extension.py      # plots with 95% bootstrap prediction intervals
